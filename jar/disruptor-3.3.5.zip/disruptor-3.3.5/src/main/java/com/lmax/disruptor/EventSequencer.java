package com.lmax.disruptor;

public interface EventSequencer<T> extends DataProvider<T>, Sequenced
{

}
